// Settings routes have been removed. API key is now configured via X-API-Key header.
// This file is kept for reference but is not registered or used.
