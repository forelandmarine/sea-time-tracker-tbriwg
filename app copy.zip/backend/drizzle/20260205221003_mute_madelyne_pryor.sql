ALTER TABLE "user" DROP COLUMN "subscription_status";--> statement-breakpoint
ALTER TABLE "user" DROP COLUMN "subscription_expires_at";--> statement-breakpoint
ALTER TABLE "user" DROP COLUMN "subscription_product_id";--> statement-breakpoint
ALTER TABLE "user" DROP COLUMN "role";