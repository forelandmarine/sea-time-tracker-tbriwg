ALTER TABLE "user" ADD COLUMN "address" text;--> statement-breakpoint
ALTER TABLE "user" ADD COLUMN "tel_no" text;--> statement-breakpoint
ALTER TABLE "user" ADD COLUMN "date_of_birth" date;--> statement-breakpoint
ALTER TABLE "user" ADD COLUMN "srb_no" text;--> statement-breakpoint
ALTER TABLE "user" ADD COLUMN "nationality" text;--> statement-breakpoint
ALTER TABLE "user" ADD COLUMN "pya_membership_no" text;