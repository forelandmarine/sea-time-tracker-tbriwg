ALTER TABLE "vessels" ADD COLUMN "engine_kilowatts" numeric(10, 2);--> statement-breakpoint
ALTER TABLE "vessels" ADD COLUMN "engine_type" text;