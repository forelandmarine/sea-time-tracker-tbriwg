ALTER TABLE "vessels" ADD COLUMN "engine_kw" numeric(10, 2);--> statement-breakpoint
ALTER TABLE "vessels" ADD COLUMN "engine_type" text;