// Initialize Natively console log capture before anything else
import './utils/errorLogger';

import 'expo-router/entry';
